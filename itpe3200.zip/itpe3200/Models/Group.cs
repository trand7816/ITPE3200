using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace itpe3200.Models;

public class Group
{
    public int Id { get; set; }
    [RegularExpression(@"[0-9a-zA-ZæøåÆØÅ. \'*-]{1,20}", ErrorMessage ="The group name must be numbers or letters between 1 to 20 characters.")]
    [Display(Name = "Group Name")]
    public string? Name { get; set; }
    [Range(0, int.MaxValue, ErrorMessage = "Groups must have a posititve value")]
    public int MaxSize { get; set; }
    
    public int CourseSessionId { get; set; }
    public CourseSession? CourseSession { get; set; }

    // the students in the group through the GroupMember join table
    public List<GroupMember> Members { get; set; } = new();
}